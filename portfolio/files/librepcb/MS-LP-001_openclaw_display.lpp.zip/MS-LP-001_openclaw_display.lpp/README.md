# MS-LP-001 OpenClaw Status Display

LibrePCB project for a small panel-mount module that shows OpenClaw container
health, token-spend rate, and active task labels on a 128 × 64 OLED.

## Files

- `project.lpp` — project metadata
- `circuit/circuit.lp` — components and netlist
- `boards/openclaw_display/` — PCB layout (to be added in REV B)
- `library/` — local components (RP2040 carrier, SSD1306, USB-C)

## Open in LibrePCB

1. Install LibrePCB 1.0+
2. File → Open Project → select `project.lpp`

## Notes

- This is the REV A development snapshot. The library/ folder is intentionally
  minimal here; the production build uses the full `librepcb-default` library
  with custom additions submitted upstream.
- BOM is targeted at Digi-Key US stock.
- Designed for matte-black soldermask + silver silkscreen.

— Mark Fuchs / Milon Studio
